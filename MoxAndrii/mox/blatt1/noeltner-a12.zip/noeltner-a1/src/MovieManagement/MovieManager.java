/*
* MovieManager
*
* Version 1.0 Moritz Nöltner
*
* You don't want to copy this.
* But if, for whatever reason, you still want to, feel free.
*/

package MovieManagement;
// We will map Actors to each Movie, therefore a HashMap seems suited
import java.util.HashMap;
import java.util.ArrayList;

public class MovieManager {
	HashMap<Movie, ArrayList<Performer>> map;
	
	public MovieManager()
	{
		map=new HashMap<Movie, ArrayList<Performer>>();
	}
	
	public void addPerformer(Movie movie, Performer performer){
		ArrayList<Performer> performers = map.get(movie);
		if(performers == null)
		{
			performers = new ArrayList<Performer>();
		}
		// Any one actor can only play in a movie once.
		if(!performers.contains(performer))
		{
			performers.add(performer);
			map.put(movie, performers);
		}
	}

	public void clearPerformers(Movie movie){
		ArrayList<Performer> performers = map.get(movie);
		if(performers != null)
		{
		performers.clear();
		map.put(movie, performers);
		}
	}
	public ArrayList<Performer> getPerformers(Movie movie){
		return map.get(movie);
	}

	public Performer getPerformer(Movie movie, int index){
		ArrayList<Performer> performers = this.getPerformers(movie);
		if(performers != null && performers.size() > index)
		{
			return performers.get(index);
		}
		return null;
	}
	public ArrayList<Performer> getOutstandingPerformers(Movie movie){
		ArrayList<Performer> performers = this.getPerformers(movie);
		ArrayList<Performer> returnList = new ArrayList<Performer>();
		
		for(Performer performer : performers)
		{
			if(performer.getOutstanding())
				returnList.add(performer);
		}
		return returnList;
	}
	
	public Boolean searchPerformer(Movie movie, String name) {
		ArrayList<Performer> performers = this.getPerformers(movie);

		for(Performer performer : performers)
		{
			if(performer.getFirstname().equalsIgnoreCase(name) && performer.getLastname().equalsIgnoreCase(name))
				return true;
		}
		return false;
	}
	
	public static void main(String args[])
	{
		System.out.println("Let's create some actors:");
		Performer performer1=new Performer("Max", "Mustermann", Gender.Male);
		Performer performer2=new Performer("Anna", "Musterfrau", Gender.Female);
		System.out.println(performer1);
		System.out.println(performer2);
		System.out.println("\nNow, let's have them marry:");
		performer1.setLastname(performer2.getLastname());
		System.out.println(performer1);
		System.out.println(performer2);
		System.out.println("\nWell, marriage is nice, but sometimes, things change. In our case, Max finds, he is really a female:");
		performer1.setGender(Gender.Female);
		performer1.setFirstname("Julia");
		System.out.println(performer1);
		System.out.println("\nAnna, who is now a wife to a wife, becomes quite a bit frustrated. To distract herself, she increases her acting training:");
		performer2.setOutstanding(true);
		System.out.println(performer2);
		System.out.println("\nThere is a new movie, starring our couple.");
		Movie movie=new Movie("Mustermovie", 92);
		System.out.println(movie);
		System.out.println("\nLet's add it to a database:");
		System.out.println("So first, let's create such a database...");
		MovieManager movman=new MovieManager();
		System.out.println("...and add the new movie to it:");
		movman.addPerformer(movie, performer1);
		movman.addPerformer(movie, performer2);
		System.out.println("\nNow, let's check the movie was added correctly, by checking which actors contributed to it:");
		System.out.println(movman.getPerformers(movie));
		System.out.println("\nLets check, if Max is also starring in the movie: " + movman.searchPerformer(movie, "Max"));
		System.out.println("\nBut is the movie good? Better check if there are any outstanding actors in it:");
		System.out.println(movman.getOutstandingPerformers(movie));
		System.out.println("Well, it looks promising, let's watch it");
		System.out.println("...\n...\n...");
		System.out.println("Now guess what: There was a mistake. Our movie was an animal film and there was not even one actor in it. Better remove the actors in our database");
		movman.clearPerformers(movie);
		System.out.println(movman.getPerformers(movie));
		System.out.println("Now! This looks better!\nThanks for your time!");
	}
}

/*
 * ArrayList:
 * - Implementiert ein Array -> Schneller Indexzugriff
 * - Langsame Suche nach Schlüsseln
 * - Implementiert nicht direkt eine Map -> Zuordnung müsste extern geschehen
 * 
 * HashSet:
 * - Implementiert eine gehashte Menge -> Schneller Schlüsselzugriff
 * - Keine Reihenfolge definierbar
 * - Implementiert nicht direkt eine Map -> Zuordnung müsste extern geschehen
 * 
 * HashMap:
 * - Implementierte eine gehashte Zuordnung -> Schneller Schlüsseszugriff
 * - Keine Reihenfolge definierbar
 * - Zugriff und Suche nach Wert langsam
 */