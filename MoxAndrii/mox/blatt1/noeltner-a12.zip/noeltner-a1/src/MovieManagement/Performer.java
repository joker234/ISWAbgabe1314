/*
* MovieManager
*
* Version 1.0 Moritz Nöltner
*
* You don't want to copy this.
* But if, for whatever reason, you still want to, feel free.
*/

package MovieManagement;


public class Performer {
	private String firstname;
	private String lastname;
	private Gender gender;
	private Boolean outstanding=false;
	//private Movie movie;	// What for?????
	
	public String getFirstname()					{ return firstname; }
	public String getLastname()						{ return lastname; }
	public Gender getGender()						{ return gender; }
	public Boolean getOutstanding()					{ return outstanding; }
	//public Movie getMovie()						{ return movie; }
	public void setFirstname(String firstname)		{ this.firstname = firstname; }
	public void setLastname(String lastname)		{ this.lastname = lastname; }
	public void setGender(Gender gender)			{ this.gender = gender; }
	public void setOutstanding(Boolean outstanding)	{ this.outstanding = outstanding; }
	//public void setMovie(Movie movie)				{ this.movie = movie; }
	
	public String toString()
	{
		return "Performer: " + this.firstname + " " + this.lastname + " is " + (this.outstanding? "an": "no") + " outstanding " + this.gender + " actor";
	}

	public Performer(String firstname, String lastname, Gender gender)
	{
		this.firstname=firstname;
		this.lastname=lastname;
		this.gender=gender;
	}
	/*public Performer(String firstname, String lastname, Gender gender, Movie movie)
	{
		this.firstname=firstname;
		this.lastname=lastname;
		this.gender=gender;
		this.movie=movie;
	}*/
}
