/*
* MovieManager
*
* Version 1.0 Moritz Nöltner
*
* You don't want to copy this.
* But if, for whatever reason, you still want to, feel free.
*/

package MovieManagement;

public enum Gender {
Male,
Female;
}
