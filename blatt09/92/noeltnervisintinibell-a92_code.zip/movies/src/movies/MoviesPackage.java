/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package movies;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see movies.MoviesFactory
 * @model kind="package"
 * @generated
 */
public interface MoviesPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "movies";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http:///movies.ecore";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "movies";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	MoviesPackage eINSTANCE = movies.impl.MoviesPackageImpl.init();

	/**
	 * The meta object id for the '{@link movies.impl.MovieImpl <em>Movie</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see movies.impl.MovieImpl
	 * @see movies.impl.MoviesPackageImpl#getMovie()
	 * @generated
	 */
	int MOVIE = 0;

	/**
	 * The feature id for the '<em><b>Title</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOVIE__TITLE = 0;

	/**
	 * The feature id for the '<em><b>Title orig</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOVIE__TITLE_ORIG = 1;

	/**
	 * The feature id for the '<em><b>Time</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOVIE__TIME = 2;

	/**
	 * The feature id for the '<em><b>Category</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOVIE__CATEGORY = 3;

	/**
	 * The feature id for the '<em><b>Rating</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOVIE__RATING = 4;

	/**
	 * The feature id for the '<em><b>Overall Rating</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOVIE__OVERALL_RATING = 5;

	/**
	 * The feature id for the '<em><b>Last Watch Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOVIE__LAST_WATCH_DATE = 6;

	/**
	 * The feature id for the '<em><b>Loaned</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOVIE__LOANED = 7;

	/**
	 * The feature id for the '<em><b>Performers</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOVIE__PERFORMERS = 8;

	/**
	 * The feature id for the '<em><b>Movie Collections</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOVIE__MOVIE_COLLECTIONS = 9;

	/**
	 * The feature id for the '<em><b>Imdb Url</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOVIE__IMDB_URL = 10;

	/**
	 * The feature id for the '<em><b>Ofdb ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOVIE__OFDB_ID = 11;

	/**
	 * The number of structural features of the '<em>Movie</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOVIE_FEATURE_COUNT = 12;

	/**
	 * The meta object id for the '{@link movies.impl.MovieCollectionImpl <em>Movie Collection</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see movies.impl.MovieCollectionImpl
	 * @see movies.impl.MoviesPackageImpl#getMovieCollection()
	 * @generated
	 */
	int MOVIE_COLLECTION = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOVIE_COLLECTION__NAME = 0;

	/**
	 * The feature id for the '<em><b>Movies</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOVIE_COLLECTION__MOVIES = 1;

	/**
	 * The number of structural features of the '<em>Movie Collection</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOVIE_COLLECTION_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link movies.impl.PerformerImpl <em>Performer</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see movies.impl.PerformerImpl
	 * @see movies.impl.MoviesPackageImpl#getPerformer()
	 * @generated
	 */
	int PERFORMER = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERFORMER__NAME = 0;

	/**
	 * The feature id for the '<em><b>Gender</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERFORMER__GENDER = 1;

	/**
	 * The feature id for the '<em><b>Rating</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERFORMER__RATING = 2;

	/**
	 * The feature id for the '<em><b>Movies</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERFORMER__MOVIES = 3;

	/**
	 * The feature id for the '<em><b>Ofdb ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERFORMER__OFDB_ID = 4;

	/**
	 * The number of structural features of the '<em>Performer</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PERFORMER_FEATURE_COUNT = 5;

	/**
	 * The meta object id for the '{@link movies.MovieCategory <em>Movie Category</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see movies.MovieCategory
	 * @see movies.impl.MoviesPackageImpl#getMovieCategory()
	 * @generated
	 */
	int MOVIE_CATEGORY = 3;

	/**
	 * The meta object id for the '{@link movies.Gender <em>Gender</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see movies.Gender
	 * @see movies.impl.MoviesPackageImpl#getGender()
	 * @generated
	 */
	int GENDER = 4;

	/**
	 * The meta object id for the '{@link movies.Rating <em>Rating</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see movies.Rating
	 * @see movies.impl.MoviesPackageImpl#getRating()
	 * @generated
	 */
	int RATING = 5;

	/**
	 * Returns the meta object for class '{@link movies.Movie <em>Movie</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Movie</em>'.
	 * @see movies.Movie
	 * @generated
	 */
	EClass getMovie();

	/**
	 * Returns the meta object for the attribute '{@link movies.Movie#getTitle <em>Title</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Title</em>'.
	 * @see movies.Movie#getTitle()
	 * @see #getMovie()
	 * @generated
	 */
	EAttribute getMovie_Title();

	/**
	 * Returns the meta object for the attribute '{@link movies.Movie#getTitle_orig <em>Title orig</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Title orig</em>'.
	 * @see movies.Movie#getTitle_orig()
	 * @see #getMovie()
	 * @generated
	 */
	EAttribute getMovie_Title_orig();

	/**
	 * Returns the meta object for the attribute '{@link movies.Movie#getTime <em>Time</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Time</em>'.
	 * @see movies.Movie#getTime()
	 * @see #getMovie()
	 * @generated
	 */
	EAttribute getMovie_Time();

	/**
	 * Returns the meta object for the attribute '{@link movies.Movie#getCategory <em>Category</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Category</em>'.
	 * @see movies.Movie#getCategory()
	 * @see #getMovie()
	 * @generated
	 */
	EAttribute getMovie_Category();

	/**
	 * Returns the meta object for the attribute '{@link movies.Movie#getRating <em>Rating</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Rating</em>'.
	 * @see movies.Movie#getRating()
	 * @see #getMovie()
	 * @generated
	 */
	EAttribute getMovie_Rating();

	/**
	 * Returns the meta object for the attribute '{@link movies.Movie#getOverallRating <em>Overall Rating</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Overall Rating</em>'.
	 * @see movies.Movie#getOverallRating()
	 * @see #getMovie()
	 * @generated
	 */
	EAttribute getMovie_OverallRating();

	/**
	 * Returns the meta object for the attribute '{@link movies.Movie#getLastWatchDate <em>Last Watch Date</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Last Watch Date</em>'.
	 * @see movies.Movie#getLastWatchDate()
	 * @see #getMovie()
	 * @generated
	 */
	EAttribute getMovie_LastWatchDate();

	/**
	 * Returns the meta object for the attribute '{@link movies.Movie#isLoaned <em>Loaned</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Loaned</em>'.
	 * @see movies.Movie#isLoaned()
	 * @see #getMovie()
	 * @generated
	 */
	EAttribute getMovie_Loaned();

	/**
	 * Returns the meta object for the reference list '{@link movies.Movie#getPerformers <em>Performers</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Performers</em>'.
	 * @see movies.Movie#getPerformers()
	 * @see #getMovie()
	 * @generated
	 */
	EReference getMovie_Performers();

	/**
	 * Returns the meta object for the reference list '{@link movies.Movie#getMovieCollections <em>Movie Collections</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Movie Collections</em>'.
	 * @see movies.Movie#getMovieCollections()
	 * @see #getMovie()
	 * @generated
	 */
	EReference getMovie_MovieCollections();

	/**
	 * Returns the meta object for the attribute '{@link movies.Movie#getImdbUrl <em>Imdb Url</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Imdb Url</em>'.
	 * @see movies.Movie#getImdbUrl()
	 * @see #getMovie()
	 * @generated
	 */
	EAttribute getMovie_ImdbUrl();

	/**
	 * Returns the meta object for the attribute '{@link movies.Movie#getOfdbID <em>Ofdb ID</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Ofdb ID</em>'.
	 * @see movies.Movie#getOfdbID()
	 * @see #getMovie()
	 * @generated
	 */
	EAttribute getMovie_OfdbID();

	/**
	 * Returns the meta object for class '{@link movies.MovieCollection <em>Movie Collection</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Movie Collection</em>'.
	 * @see movies.MovieCollection
	 * @generated
	 */
	EClass getMovieCollection();

	/**
	 * Returns the meta object for the attribute '{@link movies.MovieCollection#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see movies.MovieCollection#getName()
	 * @see #getMovieCollection()
	 * @generated
	 */
	EAttribute getMovieCollection_Name();

	/**
	 * Returns the meta object for the reference list '{@link movies.MovieCollection#getMovies <em>Movies</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Movies</em>'.
	 * @see movies.MovieCollection#getMovies()
	 * @see #getMovieCollection()
	 * @generated
	 */
	EReference getMovieCollection_Movies();

	/**
	 * Returns the meta object for class '{@link movies.Performer <em>Performer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Performer</em>'.
	 * @see movies.Performer
	 * @generated
	 */
	EClass getPerformer();

	/**
	 * Returns the meta object for the attribute '{@link movies.Performer#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see movies.Performer#getName()
	 * @see #getPerformer()
	 * @generated
	 */
	EAttribute getPerformer_Name();

	/**
	 * Returns the meta object for the attribute '{@link movies.Performer#getGender <em>Gender</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Gender</em>'.
	 * @see movies.Performer#getGender()
	 * @see #getPerformer()
	 * @generated
	 */
	EAttribute getPerformer_Gender();

	/**
	 * Returns the meta object for the attribute '{@link movies.Performer#getRating <em>Rating</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Rating</em>'.
	 * @see movies.Performer#getRating()
	 * @see #getPerformer()
	 * @generated
	 */
	EAttribute getPerformer_Rating();

	/**
	 * Returns the meta object for the reference list '{@link movies.Performer#getMovies <em>Movies</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Movies</em>'.
	 * @see movies.Performer#getMovies()
	 * @see #getPerformer()
	 * @generated
	 */
	EReference getPerformer_Movies();

	/**
	 * Returns the meta object for the attribute '{@link movies.Performer#getOfdbID <em>Ofdb ID</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Ofdb ID</em>'.
	 * @see movies.Performer#getOfdbID()
	 * @see #getPerformer()
	 * @generated
	 */
	EAttribute getPerformer_OfdbID();

	/**
	 * Returns the meta object for enum '{@link movies.MovieCategory <em>Movie Category</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Movie Category</em>'.
	 * @see movies.MovieCategory
	 * @generated
	 */
	EEnum getMovieCategory();

	/**
	 * Returns the meta object for enum '{@link movies.Gender <em>Gender</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Gender</em>'.
	 * @see movies.Gender
	 * @generated
	 */
	EEnum getGender();

	/**
	 * Returns the meta object for enum '{@link movies.Rating <em>Rating</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Rating</em>'.
	 * @see movies.Rating
	 * @generated
	 */
	EEnum getRating();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	MoviesFactory getMoviesFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link movies.impl.MovieImpl <em>Movie</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see movies.impl.MovieImpl
		 * @see movies.impl.MoviesPackageImpl#getMovie()
		 * @generated
		 */
		EClass MOVIE = eINSTANCE.getMovie();

		/**
		 * The meta object literal for the '<em><b>Title</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MOVIE__TITLE = eINSTANCE.getMovie_Title();

		/**
		 * The meta object literal for the '<em><b>Title orig</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MOVIE__TITLE_ORIG = eINSTANCE.getMovie_Title_orig();

		/**
		 * The meta object literal for the '<em><b>Time</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MOVIE__TIME = eINSTANCE.getMovie_Time();

		/**
		 * The meta object literal for the '<em><b>Category</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MOVIE__CATEGORY = eINSTANCE.getMovie_Category();

		/**
		 * The meta object literal for the '<em><b>Rating</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MOVIE__RATING = eINSTANCE.getMovie_Rating();

		/**
		 * The meta object literal for the '<em><b>Overall Rating</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MOVIE__OVERALL_RATING = eINSTANCE.getMovie_OverallRating();

		/**
		 * The meta object literal for the '<em><b>Last Watch Date</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MOVIE__LAST_WATCH_DATE = eINSTANCE.getMovie_LastWatchDate();

		/**
		 * The meta object literal for the '<em><b>Loaned</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MOVIE__LOANED = eINSTANCE.getMovie_Loaned();

		/**
		 * The meta object literal for the '<em><b>Performers</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MOVIE__PERFORMERS = eINSTANCE.getMovie_Performers();

		/**
		 * The meta object literal for the '<em><b>Movie Collections</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MOVIE__MOVIE_COLLECTIONS = eINSTANCE.getMovie_MovieCollections();

		/**
		 * The meta object literal for the '<em><b>Imdb Url</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MOVIE__IMDB_URL = eINSTANCE.getMovie_ImdbUrl();

		/**
		 * The meta object literal for the '<em><b>Ofdb ID</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MOVIE__OFDB_ID = eINSTANCE.getMovie_OfdbID();

		/**
		 * The meta object literal for the '{@link movies.impl.MovieCollectionImpl <em>Movie Collection</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see movies.impl.MovieCollectionImpl
		 * @see movies.impl.MoviesPackageImpl#getMovieCollection()
		 * @generated
		 */
		EClass MOVIE_COLLECTION = eINSTANCE.getMovieCollection();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MOVIE_COLLECTION__NAME = eINSTANCE.getMovieCollection_Name();

		/**
		 * The meta object literal for the '<em><b>Movies</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MOVIE_COLLECTION__MOVIES = eINSTANCE.getMovieCollection_Movies();

		/**
		 * The meta object literal for the '{@link movies.impl.PerformerImpl <em>Performer</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see movies.impl.PerformerImpl
		 * @see movies.impl.MoviesPackageImpl#getPerformer()
		 * @generated
		 */
		EClass PERFORMER = eINSTANCE.getPerformer();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PERFORMER__NAME = eINSTANCE.getPerformer_Name();

		/**
		 * The meta object literal for the '<em><b>Gender</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PERFORMER__GENDER = eINSTANCE.getPerformer_Gender();

		/**
		 * The meta object literal for the '<em><b>Rating</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PERFORMER__RATING = eINSTANCE.getPerformer_Rating();

		/**
		 * The meta object literal for the '<em><b>Movies</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PERFORMER__MOVIES = eINSTANCE.getPerformer_Movies();

		/**
		 * The meta object literal for the '<em><b>Ofdb ID</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PERFORMER__OFDB_ID = eINSTANCE.getPerformer_OfdbID();

		/**
		 * The meta object literal for the '{@link movies.MovieCategory <em>Movie Category</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see movies.MovieCategory
		 * @see movies.impl.MoviesPackageImpl#getMovieCategory()
		 * @generated
		 */
		EEnum MOVIE_CATEGORY = eINSTANCE.getMovieCategory();

		/**
		 * The meta object literal for the '{@link movies.Gender <em>Gender</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see movies.Gender
		 * @see movies.impl.MoviesPackageImpl#getGender()
		 * @generated
		 */
		EEnum GENDER = eINSTANCE.getGender();

		/**
		 * The meta object literal for the '{@link movies.Rating <em>Rating</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see movies.Rating
		 * @see movies.impl.MoviesPackageImpl#getRating()
		 * @generated
		 */
		EEnum RATING = eINSTANCE.getRating();

	}

} //MoviesPackage
