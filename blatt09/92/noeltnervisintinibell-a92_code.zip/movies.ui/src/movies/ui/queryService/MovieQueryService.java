package movies.ui.queryService;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.net.UnknownHostException;
import java.util.ArrayList;

import javax.xml.parsers.ParserConfigurationException;

import org.eclipse.emf.common.util.EList;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import movies.Movie;
import movies.Performer;


/**
 * The Class MovieQueryServiceImpl.
 */
public class MovieQueryService {

	/** The Constant SEARCH_URL. */
	private static final String SEARCH_URL = "http://ofdbgw.org/search/"; //nimmt String
	
	/** The Constant MOVIE_URL. */
	private static final String MOVIE_URL = "http://ofdbgw.org/movie/"; //Nimmt movie id
	
	/** The Constant imdb2ofdb. */
	@SuppressWarnings("unused")
	private static final String IMDB2OFDB = "http://ofdbgw.org/imdb2ofdb/"; //nimmt Imdb ID
			
	/** The Constant personURL. */
	@SuppressWarnings("unused")
	private static final String PERSON_URL = "http://ofdbgw.org/searchperson/"; //Nimmt string
	
	/** The Constant singlepersonURL. */
	private static final String SINGLEPERSON_URL = "http://ofdbgw.org/person/"; //Nimmt Personen ID

	/** The dom parser. */
	private XMLDOMParser domParser = new XMLDOMParser();
	
	/** The Constant SPECIFY_PERFORMER. 
	 * true: Weitere Informationen �ber performer werden abgerufen. Verlangsamt die wartezeit!
	 * false: keine weiteren Informationen �ber Performer werden abgerufen. Verk�rzt die Wartezeit!
	 */
	private static final boolean SPECIFY_PERFORMER = true;
	
	/**
	 * Complete url.
	 * F�ge Subdomains ein.
	 * 2 URLs auskommentiert da keine Konstistenen Ergebnisse
	 *
	 * @param sURL the s url
	 * @param key the key
	 * @return the string
	 */
	private String completeURL(String sURL, String key){
		ArrayList<String> subDomains = new ArrayList<String>();
		
		subDomains.add("http://ofdbgw.scheeper.de/");
		subDomains.add("http://ofdbgw.home-of-root.de/");
		subDomains.add("http://ofdbgw.metawave.ch/");
//		subDomains.add("http://ofdbgw.h1915283.stratoserver.net/"); 
//		subDomains.add("http://ofdbgw.johann-scharl.de/");
		subDomains.add("http://ofdbgw.geeksphere.de/");	
		
		int random = (int)( Math.random() * subDomains.size());
		
		String newURL = sURL.replaceFirst("http://ofdbgw.org/", subDomains.get(random));
		
		newURL = newURL + key;
		
		return newURL;
	}
	
	
	/**
	 * Connect url.
	 *
	 * @param sURL �bergebene Konstante, oben definiert, gibt an nach was gesucht wird.
	 * @param key Das SChl�sselwort nach welchem gesucht wird
	 * @return the input stream Antwart der Datenbank als input stream
	 * 
	 * Baut eine Verbindung zur ofdb Datenbank auf.
	 */
	private InputStream connectURL(String sURL, String key) throws Exception {
	
		key = key.replaceAll(" ","%20");// <- Wichtig!
		URL	url = new URL(completeURL( sURL , key));	
		URLConnection connected = url.openConnection();	
			
		return connected.getInputStream();
	}

	/**
	 * Gets the list of near movies.
	 * 
	 * 1.Stufe: Suche nach Filmen mit bestimmten Namen.
	 * Die while Schleife sorgt daf�r das im falle eines Timeouts die anfrage erneut ausgef�hrt wird
	 *
	 * @param key the key
	 * @return the list of near movies
	 * 
	 */
	public EList<Movie> getListOfNearMovies(String key) {
		try{
			EList<Movie> movies = null;
	
	       	while ((movies = domParser.parseNearMovies(connectURL(SEARCH_URL, key))) == null){}
	        
	       	return movies; 
		}catch( UnknownHostException e) {
			System.err.println("Verbindung fehlgeschlagen, bitte Netzwerkverbindung �berpr�fen!");
			return null;
		}catch(NullPointerException e) {
			System.err.println("Konnte keine Verbindung zu Host hertellen, bitte erneut versuchen");
			return null;
		} catch (IOException e) {
			System.err.println("Verbindungsfehler");
			return null;
		} catch (Exception e) {
			System.err.println("Error");
			return null;
		}
	}
	
	/**
	 * Complete movie information.
	 *
	 * Stufe 2: Ein Movie wird �bergeben, anhand seiner OfdbID werden weitere Informationen abgefragt.
	 * Die while Schleife sorgt daf�r das im falle eines Timeouts die anfrage erneut ausgef�hrt wird.
	 *
	 * @param pMmovie the mmovie
	 * @return the movie
	 * 
	 */
	public Movie completeMovieInformation(Movie pMmovie) {
		try{
			Movie movie;
			
			while ((movie = domParser.parseExtendetMovieInformation(
					pMmovie, connectURL(MOVIE_URL, pMmovie.getOfdbID()))) == null){}
			
			return movie;
		}catch(UnknownHostException e) {
			System.err.println("Verbindung fehlgeschlagen, bitte Netzwerkverbindung �berpr�fen!");
			return null;
		}catch(NullPointerException e) {
			System.err.println("Konnte keine Verbindung zu Host hertellen, bitte erneut versuchen");
			return null;
		} catch (IOException e) {
			System.err.println("Verbindungsfehler");
			return null;
		}catch (SAXParseException e){
			return null;
		} catch (SAXException e) {
			return null;
		} catch (ParserConfigurationException e) {
			return null;
		} catch (Exception e) {
			System.err.println("Error");
			return null;
		} 
	}
	
	/**
	 * Complete performer information.
	 * 
	 * Stufe 3: Die Performer eines Filmes bekommen weitere Atribute hinzugef�gt.
	 * Die while Schleife sorgt daf�r das im falle eines Timeouts die anfrage erneut ausgef�hrt wird.
	 *
	 * @param pPerformer the performer der erweitert werden soll
	 * @return the performer der erweiterte performer wird zur�ck gegeben
	 * 
	 */
	
	public Performer completePerformerInformation (Performer pPerformer) {
		try{
			if(SPECIFY_PERFORMER){
				Performer performer = pPerformer;
				if(!pPerformer.getOfdbID().isEmpty()){	
					while((performer = domParser.parsePerformerInformation(
							pPerformer, connectURL(SINGLEPERSON_URL, pPerformer.getOfdbID()))) == null){}
				}	
				return performer;
			}else{
				return pPerformer;
			}
		} catch(UnknownHostException e) {
			System.err.println("Verbindung fehlgeschlagen, bitte Netzwerkverbindung �berpr�fen!");
			return null;
		} catch(NullPointerException e) {
			System.err.println("Konnte keine Verbindung zu Host hertellen, bitte erneut versuchen");
			return null;
		} catch (IOException e) {
			System.err.println("Verbindungsfehler");
			return null;
		} catch ( SAXParseException e){
			return null;
		} catch (SAXException e) {
			return null;
		} catch (ParserConfigurationException e) {
			return null;
		} catch (Exception e) {
			System.err.println("Error");
			return null;
		}
	}
}
