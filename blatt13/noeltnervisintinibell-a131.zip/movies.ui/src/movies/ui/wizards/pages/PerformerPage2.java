
package movies.ui.wizards.pages;
import java.util.ArrayList;
import java.util.List;
import movies.Movie;
import movies.MoviesPackage;
import movies.ui.util.MovieUtil;
import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
/**
 * Class representing the second step for performer creating. In this step it is
 * possible to select movies to link the created performer with
 *
 */
public class PerformerPage2 extends WizardPage {
	/** List with check boxes for each movie. */
	private List<Button> buttons = new ArrayList<Button>();
	/**
	 * @param pageName
	 *
	 * String defining the WizardPage name
	 */
	public PerformerPage2(String pageName)
	{
		super(pageName);
		setTitle(pageName);
		setDescription("Step 2: Link Performer with existing Movies");
	}
	@Override
	public void createControl(Composite parent)
	{
		Composite container = new Composite(parent, SWT.NONE);
		GridLayout layout = new GridLayout();
		container.setLayout(layout);
		layout.numColumns = 3;
		// fetch all existing movies
		EList<Movie> movies = MovieUtil.getActiveProject()
		                      .getAllModelElementsbyClass(MoviesPackage.eINSTANCE.getMovie(),
		                                                  new BasicEList<Movie>());
		// Create a check box for each movie
		for (Movie m : movies)
		{
			Button mb = new Button(container, SWT.CHECK);
			mb.setText(m.getTitle());
			// attach the movie instance as data element to the button
			mb.setData(m);
			buttons.add(mb);
		}
		// Required to avoid an error in the system
		setControl(container);
		setPageComplete(true);
	}
	/**
	 * @return a List with selected Movies to be linked with the
	 */
	public EList<Movie> getSelectedMovies()
	{
		EList<Movie> sm = new BasicEList<Movie>();
		for (Button b : buttons)
		{
			if (b.getSelection())	// button has to be selected
			{
				if (b.getData() != null)// data element has to be set
				{
					if (b.getData() instanceof Movie)	// and a Movie
					{
						sm.add((Movie) b.getData());
					}
				}
			}
		}
		return sm;
	}
}
