package movies.ui.wizards.pages;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.widgets.Composite;

import movies.Gender;
import movies.Rating;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

/**
 * Class representing the first step for performer creating. In this step it the
 * attributes of the created performer are defined
 */
public class PerformerPage1 extends WizardPage {
	private Text textName;
	private Button genderMButton;
	private Button genderFButton;
	private Combo ratingDropDown;
	private Composite container;
	/**
	 * @param pageName
	 *
	 * String defining the WizardPage name
	 */
	public PerformerPage1(String pageName)
	{
		super(pageName);
		setTitle(pageName);
		setDescription("Step 1: Creat a new Performer");
	}
	@Override
	public void createControl(Composite parent)
	{
		// container element for aggregation and layout of the single UI
		// elements
		container = new Composite(parent, SWT.NONE);
		GridLayout layout = new GridLayout();
		container.setLayout(layout);
		layout.numColumns = 2;
		// Text Input field for Performer name definition
		Label label1 = new Label(container, SWT.NONE);
		label1.setText("Name:");
		textName = new Text(container, SWT.BORDER | SWT.SINGLE);
		textName.setText("");
		// avoid empty performer name
		textName.addKeyListener(new KeyAdapter()
		{
			@Override
			public void keyReleased(KeyEvent e)
			{
				if (!textName.getText().isEmpty())
				{
					setPageComplete(true);
				}
			}
		});
		GridData gd = new GridData(GridData.FILL_HORIZONTAL);
		textName.setLayoutData(gd);
		// Radio Button for Performer Gender definition
		Label label2 = new Label(container, SWT.NONE);
		label2.setText("Gender:");
		genderFButton = new Button(container, SWT.RADIO);
		genderFButton.setText("Female");
		Label blank = new Label(container, SWT.NONE);
		blank.setText("");
		genderMButton = new Button(container, SWT.RADIO);
		genderMButton.setText("Male");
		// DropDown Box for Rating
		Label label3 = new Label(container, SWT.NONE);
		label3.setText("Rating:");
		ratingDropDown = new Combo(container, SWT.DROP_DOWN | SWT.BORDER);
		for (int i = 0; i < 6; i++)
		{
			ratingDropDown.add("" + i);
		}
		ratingDropDown.select(0);
		// Required to avoid an error in the system
		setControl(container);
		setPageComplete(false);
	}
	/**
	 * @return the Name of the Performer to create
	 */
	public String getPerformerName()
	{
		return textName.getText();
	}
	/**
	 * @return the Gender of the Performer to create
	 */
	public Gender getGender()
	{
		return genderFButton.getSelection() ? Gender.FEMALE : Gender.MALE;
	}
	/**
	 * @return the Rating of the Performer to create
	 */
	public Rating getRating()
	{
		return Rating.get(ratingDropDown.getSelectionIndex());
	}
}
