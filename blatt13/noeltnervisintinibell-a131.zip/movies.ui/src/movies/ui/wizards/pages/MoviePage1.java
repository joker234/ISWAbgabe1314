package movies.ui.wizards.pages;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.widgets.Composite;

import movies.Gender;
import movies.Movie;
import movies.Rating;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;
import movies.ui.queryService.MovieQueryService;

/**
 * Class representing the first step for movie creating. In this step it the
 * attributes of the created movie are defined
 */
public class MoviePage1 extends WizardPage {
	private Text textSearchName;
	private Text textTitleB;
	private Text textOrigTitleB;
	private Text textTimeB;
	private Text textRatingB;
	private Text textCategoryB;
	private EList<Movie> nearMovies;
	private Movie originalMovie;		// The movie to be synced (or a new Movie)
	private Movie chosenNearMovie;		// The movie which provides the data to be copied
	private Composite container;
	private Composite containerLeft;
	private Composite containerRight;
	private Combo suggestionDropDown;
	
	
	
	
	/**
	 * @param pageName
	 *
	 * String defining the WizardPage name
	 */
	public MoviePage1(String pageName, Movie originalMovie)
	{
		super(pageName);
		setTitle(pageName);
		setDescription("Step 1: Create a new Movie");
		this.originalMovie=originalMovie;
	}
	
	private void updateSuggestionDropDown()
	{
		if(nearMovies != null)
		{
			suggestionDropDown.removeAll();
			for(Movie movie : nearMovies)
			{
				suggestionDropDown.add(movie.getTitle());
			}
			suggestionDropDown.select(0);
		}
	}
	
	private void updateB()
	{
		Movie selectedMovie = nearMovies.get(suggestionDropDown.getSelectionIndex());
		textTitleB.setText(selectedMovie.getTitle());
		textOrigTitleB.setText(selectedMovie.getTitle_orig());
		textTimeB.setText(new Integer(selectedMovie.getTime()).toString());
		textRatingB.setText(selectedMovie.getRating().toString());
		textCategoryB.setText(selectedMovie.getCategory().toString());
	}
	
	
	@Override
	public void createControl(Composite parent)
	{
		// container element for aggregation and layout of the single UI // elements
		container = new Composite(parent, SWT.NONE);
		GridLayout layout = new GridLayout();
		container.setLayout(layout);
		layout.numColumns = 2;
		
		
		containerLeft = new Composite(container, SWT.NONE);
		GridLayout layoutLeft = new GridLayout();
		containerLeft.setLayout(layoutLeft);
		layoutLeft.numColumns = 2;
		
		containerRight = new Composite(container, SWT.NONE);
		GridLayout layoutRight = new GridLayout();
		containerRight.setLayout(layoutRight);
		layoutRight.numColumns = 2;
		
		
		
		// Text Input field for Movie name definition
		Label namelabel = new Label(containerLeft, SWT.NONE);
		namelabel.setText("Name:");
		textSearchName = new Text(containerLeft, SWT.BORDER | SWT.SINGLE);
		textSearchName.setText("");
		// avoid empty movie name
		textSearchName.addKeyListener(new KeyAdapter()
		{
			@Override
			public void keyReleased(KeyEvent e)
			{
				if (!textSearchName.getText().isEmpty())
				{
					suggestionDropDown.removeAll();
					suggestionDropDown.select(0);
					final String nearMovieName = textSearchName.getText(); 
					Thread t = new Thread() {
						private void searchNearMovies(String title)
						{
							MovieQueryService mqs = new MovieQueryService();
							if (mqs.getListOfNearMovies(title) != null)
							{
								nearMovies = mqs.getListOfNearMovies(title);
							}
						}

						public void run()
						{
							searchNearMovies(nearMovieName);
							try {
								this.join();
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
							
					};
					t.start();
					//searchNearMovies(textSearchName.getText());
					updateSuggestionDropDown();
					// TODO: Hier Suchanfrage starten
					// TODO: updateSuggestionDropdown();
					setPageComplete(true);
				}
			}
		});
		GridData gd = new GridData(GridData.FILL_HORIZONTAL);
		textSearchName.setLayoutData(gd);

		// DropDown Box zur Auswahl
		Label dropdownlabel = new Label(containerRight, SWT.NONE);
		dropdownlabel.setText("Suchergebnisse:");
		suggestionDropDown = new Combo(containerRight, SWT.DROP_DOWN | SWT.BORDER);
		updateSuggestionDropDown();

		// 
		Label labelTitleA = new Label(containerLeft, SWT.NONE);
		labelTitleA.setText("Title:");
		Text textTitleA = new Text(containerLeft, SWT.BORDER | SWT.SINGLE);
		textTitleA.setText(originalMovie.getTitle());
		textTitleA.setEditable(false);

		Label labelOrigTitleA = new Label(containerLeft, SWT.NONE);
		labelOrigTitleA.setText("Orig. Title:");
		Text textOrigTitleA = new Text(containerLeft, SWT.BORDER | SWT.SINGLE);
		textOrigTitleA.setText(originalMovie.getTitle_orig());
		textOrigTitleA.setEditable(false);
		
		Label labelTimeA = new Label(containerLeft, SWT.NONE);
		labelTimeA.setText("Time:");
		Text textTimeA = new Text(containerLeft, SWT.BORDER | SWT.SINGLE);
		textTimeA.setText(new Integer(originalMovie.getTime()).toString());
		textTimeA.setEditable(false);
		
		Label labelRatingA = new Label(containerLeft, SWT.NONE);
		labelRatingA.setText("Rating:");
		Text textRatingA = new Text(containerLeft, SWT.BORDER | SWT.SINGLE);
		textRatingA.setText(originalMovie.getRating().toString());
		textRatingA.setEditable(false);
		
		Label labelCategoryA = new Label(containerLeft, SWT.NONE);
		labelCategoryA.setText("Category:");
		Text textCategoryA = new Text(containerLeft, SWT.BORDER | SWT.SINGLE);
		textCategoryA.setText(originalMovie.getCategory().toString());
		textCategoryA.setEditable(false);
		
		// 
		Button buttonTitleB = new Button(containerRight, SWT.CHECK);
		textTitleB = new Text(containerRight, SWT.BORDER | SWT.SINGLE);
		textTitleB.setEditable(false);

		Button buttonOrigTitleB = new Button(containerRight, SWT.CHECK);
		textOrigTitleB = new Text(containerRight, SWT.BORDER | SWT.SINGLE);
		textOrigTitleB.setEditable(false);
		
		Button buttonTimeB = new Button(containerRight, SWT.CHECK);
		textTimeB = new Text(containerRight, SWT.BORDER | SWT.SINGLE);
		textTimeB.setEditable(false);
		
		Button buttonRatingB = new Button(containerRight, SWT.CHECK);
		textRatingB = new Text(containerRight, SWT.BORDER | SWT.SINGLE);
		textRatingB.setEditable(false);
		
		Button buttonCategoryB = new Button(containerRight, SWT.CHECK);
		textCategoryB = new Text(containerRight, SWT.BORDER | SWT.SINGLE);
		textCategoryB.setEditable(false);
		
		suggestionDropDown.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				updateB();
			}
		});
		
		
		
//		// Radio Button for Movie Gender definition
//		Label label2 = new Label(container, SWT.NONE);
//		label2.setText("Gender:");
//		//genderFButton = new Button(container, SWT.RADIO);
//		//genderFButton.setText("Female");
//		Label blank = new Label(container, SWT.NONE);
//		blank.setText("");
//		//genderMButton = new Button(container, SWT.RADIO);
//		//genderMButton.setText("Male");
//		// Required to avoid an error in the system
		setControl(container);
		setPageComplete(false);
	}
	/**
	 * @return the Name of the Movie to create
	 */
	public String getMovieTitle()
	{
		return textSearchName.getText();
	}
	/**
	 * @return the Gender of the Movie to create
	 */
	//public Gender getGender()
	//{
	//	return genderFButton.getSelection() ? Gender.FEMALE : Gender.MALE;
	//}
	/**
	 * @return the Rating of the Movie to create
	 */
	//public Rating getRating()
	//{
	//	return Rating.get(ratingDropDown.getSelectionIndex());
	//}
}
