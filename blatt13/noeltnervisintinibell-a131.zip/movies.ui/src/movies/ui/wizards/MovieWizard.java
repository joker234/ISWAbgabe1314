package movies.ui.wizards;
import java.util.Date;

import movies.Movie;
import movies.MovieCategory;
import movies.MoviesFactory;
import movies.Performer;
import movies.Rating;
import movies.ui.util.MovieUtil;
import movies.ui.wizards.pages.MoviePage1;
import movies.ui.wizards.pages.MoviePage2;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecp.common.utilities.ActionHelper;
import org.eclipse.emf.emfstore.client.model.util.EMFStoreCommand;
import org.eclipse.jface.wizard.Wizard;
/**
 * Class representing a Wizard to create a Movie (1. Step)
 * and link the Movie with existing Movies (2. Step)
 *
 */
public class MovieWizard extends Wizard {
	/** Wizard Page for Steop 1 to create a Movie. */
	private MoviePage1 pp1;
	/** Wizard Page for Step 2 to link the Movie with existing Movies. */
	private MoviePage2 pp2;
	
	private Movie originalMovie;

	/** Default constructor with ProgressMonitor activaton */
	public MovieWizard() {
		super();
		setNeedsProgressMonitor(true);
		originalMovie = MoviesFactory.eINSTANCE.createMovie();
		originalMovie.setTitle("");
		originalMovie.setTitle_orig("");
		originalMovie.setTime(0);
		originalMovie.setCategory(MovieCategory.ACTION);
		originalMovie.setRating(Rating.ZERO);
		originalMovie.setOverallRating("");
		originalMovie.setLastWatchDate(new Date());
		originalMovie.setLoaned(false);
		originalMovie.setSynced(false);
	}

	public MovieWizard(Movie originalMovie) {
		super();
		setNeedsProgressMonitor(true);
		this.originalMovie=originalMovie;
	}

	@Override
	public void addPages() {
		pp1 = new MoviePage1("Create Movie", originalMovie);
		pp2 = new MoviePage2("Link Movie to assoziated Movies");
		addPage(pp1);
		addPage(pp2);
	}
	@Override
	public boolean performFinish() {
		// define the operations to perfom when finishing the Wizard
		// // EMF-Store operations have to be executed inseide an EMFStoreCommand
		new EMFStoreCommand() {
			protected void doRun() {
				// create a new Perfomer instance
				Movie nm = MoviesFactory.eINSTANCE.createMovie();
				// fetch movie data from 1. WizardPage
				nm.setTitle(pp1.getMovieTitle());
				//nm.setGender(pp1.getGender());
				//nm.setRating(pp1.getRating());
				// fetch seleted movies from 2. WizardPage
				EList<Movie> sm = pp2.getSelectedMovies();
				// bidirectional link movie with the selected movies
				for(Movie m : sm) {
				//TODO	nm.getPerformers().add(m); // movie to performer
				//TODO	m.getMovies().add(nm); // performer to movie
				}
				// add the movie to the actual project
				MovieUtil.getActiveProject().addModelElement(nm);
				// open detail vies of the newly createc movie
				ActionHelper.openModelElement(nm, pp2.getName());
			}
		}.run();
		return true;
	}
}

