package movies.ui.wizards;
import movies.Movie;
import movies.MoviesFactory;
import movies.Performer;
import movies.ui.util.MovieUtil;
import movies.ui.wizards.pages.PerformerPage1;
import movies.ui.wizards.pages.PerformerPage2;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecp.common.utilities.ActionHelper;
import org.eclipse.emf.emfstore.client.model.util.EMFStoreCommand;
import org.eclipse.jface.wizard.Wizard;
/**
 * Class representing a Wizard to create a Performer (1. Step)
 * and link the Performer with existing Movies (2. Step)
 *
 */
public class PerformerWizard extends Wizard {
	/** Wizard Page for Steop 1 to create a Performer. */
	private PerformerPage1 pp1;
	/** Wizard Page for Step 2 to link the Performer with existing Movies. */
	private PerformerPage2 pp2;

	/** Default constructor with ProgressMonitor activaton */
	public PerformerWizard() {
		super();
		setNeedsProgressMonitor(true);
	}

	@Override
	public void addPages() {
		pp1 = new PerformerPage1("Create Performer");
		pp2 = new PerformerPage2("Link Performer to assoziated Movies");
		addPage(pp1);
		addPage(pp2);
	}
	@Override
	public boolean performFinish() {
		// define the operations to perfom when finishing the Wizard
		// // EMF-Store operations have to be executed inseide an EMFStoreCommand
		new EMFStoreCommand() {
			protected void doRun() {
				// create a new Perfomer instance
				Performer np = MoviesFactory.eINSTANCE.createPerformer();
				// fetch performer data from 1. WizardPage
				np.setName(pp1.getPerformerName());
				np.setGender(pp1.getGender());
				np.setRating(pp1.getRating());
				// fetch seleted movies from 2. WizardPage
				EList<Movie> sm = pp2.getSelectedMovies();
				// bidirectional link performer with the selected movies
				for(Movie m : sm) {
					np.getMovies().add(m); // performer to movie
					m.getPerformers().add(np); // movie to performer
				}
				// add the performer to the actual project
				MovieUtil.getActiveProject().addModelElement(np);
				// open detail vies of the newly createc performer
				ActionHelper.openModelElement(np, pp2.getName());
			}
		}.run();
		return true;
	}
}

