package movies.ui.dialogs;


import movies.Movie;

import org.eclipse.emf.common.util.EList;
import org.eclipse.jface.dialogs.TitleAreaDialog;
import org.eclipse.jface.text.Document;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.TextViewer;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;

public class LoanedMoviesSimpleDialog extends TitleAreaDialog
{
	EList<Movie> movies;

	public LoanedMoviesSimpleDialog(Shell parentShell, EList<Movie> movies)
	{
		super(parentShell);
		this.movies=movies;
	}

	@Override
	protected Control createDialogArea(Composite parent)
	{
		Composite composite = (Composite) super.createDialogArea(parent);

		// set title and message
		setTitle("Loaned Movies");
		setMessage("These Movies are currently loaned");

		// Create a table
		Table table = new Table(composite, SWT.FULL_SELECTION | SWT.BORDER);
		table.setLayoutData(new GridData(GridData.FILL_BOTH));

		// Create one column and show
		TableColumn moviesColumn = new TableColumn(table, SWT.LEFT);
		moviesColumn.setText("Loaned Movie");

		// No need to show it here
		table.setHeaderVisible(false);

		// run through the list, add all loaned movies to the table
		for (Movie movie : this.movies) {
			if(movie.isLoaned())
			{
				TableItem item = new TableItem(table, SWT.NONE);
				item.setText(0, movie.getTitle());
			}
		}

		moviesColumn.pack();

		return composite;
	}





	@Override
	protected void okPressed()
	{
		this.setReturnCode(Window.OK);
		super.okPressed();
	}

	@Override
	protected void cancelPressed()
	{
		super.cancelPressed();
	}
}
