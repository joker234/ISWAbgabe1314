package movies.ui.handler;
import movies.ui.dialogs.SimpleDialog;
import movies.ui.wizards.MovieWizard;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.ui.PlatformUI;
public class MovieWizardHandler extends AbstractHandler {
	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		WizardDialog wd = new WizardDialog(PlatformUI.getWorkbench()
				.getActiveWorkbenchWindow().getShell(), new MovieWizard());
		wd.setPageSize(480, 320);
		wd.open();
		return null;
	}

}