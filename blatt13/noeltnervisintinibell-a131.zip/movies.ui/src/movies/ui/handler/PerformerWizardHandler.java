package movies.ui.handler;
import movies.ui.dialogs.SimpleDialog;
import movies.ui.wizards.PerformerWizard;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.ui.PlatformUI;
public class PerformerWizardHandler extends AbstractHandler {
	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		WizardDialog wd = new WizardDialog(PlatformUI.getWorkbench()
				.getActiveWorkbenchWindow().getShell(), new PerformerWizard());
		wd.setPageSize(480, 320);
		wd.open();
		return null;
	}

}