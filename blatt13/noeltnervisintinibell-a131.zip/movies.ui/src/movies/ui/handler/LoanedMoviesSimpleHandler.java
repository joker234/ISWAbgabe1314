package movies.ui.handler;

import movies.Movie;
import movies.MoviesPackage;
import movies.ui.dialogs.LoanedMoviesSimpleDialog;
import movies.ui.util.MovieUtil;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.emfstore.common.model.Project;
import org.eclipse.ui.PlatformUI;

public class LoanedMoviesSimpleHandler extends AbstractHandler {
	/*
	 * (non-Javadoc)
	 *
	 * @see org.eclipse.core.commands.AbstractHandler#execute(org.eclipse.core.commands.ExecutionEvent)
	 */
	public Object execute(ExecutionEvent event) throws ExecutionException
	{
		Project p = MovieUtil.getActiveProject();
		if (p != null)
		{
			EList<Movie> movies = p.getAllModelElementsbyClass(MoviesPackage.eINSTANCE.getMovie(), new BasicEList<Movie>());

			LoanedMoviesSimpleDialog dialog = new LoanedMoviesSimpleDialog(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell(), movies);
			dialog.open();
		}
		return null;
	}
}
