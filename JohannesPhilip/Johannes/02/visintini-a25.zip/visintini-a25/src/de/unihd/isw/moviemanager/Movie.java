package de.unihd.isw.moviemanager;

import java.util.HashSet;
import java.util.Set;
import java.util.Iterator;

/**
 * @author Johannes Visintini
 *
 */
public class Movie {
	/**
	 * stores the title.
	 */
	private String title;
	/**
	 * stores the duration.
	 */
	private int time;
	/**
	 * stores the internal number of movie.
	 */
	private final int number;
	/**
	 * stores next available internal number for next movie.
	 * nextnummer has value zero per default
	 * Google CodePro AnalytiX: should be final. Can't be,
	 * because nextnummer should be changed in the class.
	 */
	private static int nextnummer;
	
	
	/**
	 * saves Performers in HashSet
	 * I used a HashSet because HashMap is not necessary, the values ar not
	 * necessary. ArrayList is not necessary either because the values (performers)
	 * have no order.
	 */
	private final Set<Performer> set = new HashSet<Performer>();

	/**
	 * @param title Title
	 * @param time duration
	 * constructor for movie class.
	 */
	public Movie(String title, int time) {
		super();
		this.title = title;
		this.time = time;
		this.number = nextnummer;
		nextnummer++;
	}
	
	/**
	 * @return title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * Die Funktion bekommt einen Titel in die Variable title übergeben und setzt
	 * diese dann als Titel in dem Objekt der Klasse Movie (this.title)
	 */
	/**
	 * @param title
	 * changes title
	 */
	public void setTitle(String title) {
		this.title = title;
	} 

	/**
	 * @return duration
	 */
	public int getTime() {
		return time;
	}

	/**
	 * @param time
	 * changes duration
	 */
	public void setTime(int time) {
		this.time = time;
	}
	
	/**
	 * @return number
	 */
	public int getNumber() {
		return number;
	}
	
	/**
	 * print out all available Basic information.
	 */
	public void showInformation() {
		System.out.println("Nummer:"+this.getNumber());
		System.out.println("Titel:"+this.getTitle());
		System.out.println("Länge:"+this.getTime());
	}
	
	/**
	 * @param p performer
	 * adds the performer to the set
	 */
	public void addPerformer(Performer p) {
		this.set.add(p);
	}
	
	/**
	 * @return all performers as HashSet
	 */
	public Set<Performer> getPerformer() {
		return set;
	}

	/**
	 * @param ss searchstring
	 * @return if String ss is contained in the name of Performers
	 */
	public boolean isPerformer(String ss) {
		final Performer[] array = this.getPerformer().toArray(new Performer[getPerformer().size()]);
		boolean out = false;
		for(int i=0;i<array.length;i++) {
			out = (array[i].getFirstname().contains(ss)||array[i].getLastname().contains(ss));
			if (out) { break; }
		}
		return out;
	}
	
	/**
	 * @return all outstanding performers
	 */
	public Set<Performer> getOutstandingPerformer() {
		final Set<Performer> out = new HashSet<Performer>();
		final Iterator<Performer> it = set.iterator();
		Performer cur;
		for (; it.hasNext();) {
			cur = it.next();
			if (cur.isOutstanding()) {
				out.add(cur);
			}
		}
		return out;
	}
	
	/**
	 * @param p performer
	 * remove Performers from HashSet
	 */
	public void removePerformer(Performer p) {
		set.remove(p);
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 * overload toString for better print-Output
	 */
	/**
	 * @return formitted movie
	 */
	public String toString() {
		return title+" ("+time+")";
	}
	
	/**
	 * @param args command line parameters
	 */
	public static void main(String[] args) {
		final Movie film;
		film = new Movie("Häwassollndas",50);
		film.showInformation();
	}

}
