package de.unihd.isw.moviemanager;

/**
 * @author joe
 * @version 1.0
 */
public class Director extends Performer {
	/**
	 * stores how many movies the Director directed. 
	 */
	private int anzahlFilme;

	/**
	 * @param firstname Vorname des Direktors
	 * @param lastname Nachname des Direktors
	 * @param gender Gender des Direktors
	 * @param movie Film des Direktors
	 * @param outstanding outstanding des Direktors
	 * @param anzahlFilme anzahlFilme des Direktors
	 */
	public Director(String firstname, String lastname, Gender gender,
			Movie movie, boolean outstanding, int anzahlFilme) {
		super(firstname, lastname, gender, movie, outstanding);
		this.anzahlFilme = anzahlFilme;
	}

	/**
	 * @param firstname Vorname des Direktors
	 * @param lastname Nachname des Direktors
	 * @param gender Gender des Direktors
	 * @param movie Film des Direktors
	 * @param anzahlFilme anzahlFilme des Direktors
	 */
	public Director(String firstname, String lastname, Gender gender,
			Movie movie, int anzahlFilme) {
		super(firstname, lastname, gender, movie);
		this.anzahlFilme = anzahlFilme;
	}

	/**
	 * @return how many movies the Director directed
	 */
	public int getAnzahlFilme() {
		return anzahlFilme;
	}

	/**
	 * @param anzahlFilme sets how many movies the Director directed
	 */
	public void setAnzahlFilme(int anzahlFilme) {
		this.anzahlFilme = anzahlFilme;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	/**
	 * overload toString for better print-Output.
	 * @return formatted string
	 */
	public String toString() {
		return "Name: "+getFirstname()+" "+getLastname()+LINESEP+
		"Geschlecht: "+getGender()+LINESEP+
		"Movie: "+getMovie()+LINESEP+
		"Outstanding: "+isOutstanding()+LINESEP+
		"anzahl Filme Regie geführt: "+anzahlFilme+LINESEP;
	}
}
