package de.unihd.isw.moviemanager;

/**
 * @author Johannes Visintini
 * @version 1.0
 */
public class Performer {
	/**
	 * saves the fucking firstname.
	 */
	private String firstname;
	/**
	 * saves the lastname.
	 */
	private String lastname;
	/**
	 * saves the current gender of the performer.
	 */
	private Gender gender;
	/**
	 * saves a movie or stuff like that.
	 */
	private Movie movie;
	/**
	 * is the performer outstanding?
	 */
	private boolean outstanding;
	/**
	 * get the lineSeperator.
	 */
	static final String LINESEP = System.getProperty("line.separator");

	/**
	 * @param firstname Firstname
	 * @param lastname Lastname
	 * @param gender Gender
	 * @param movie Movie
	 * @param outstanding Outstanding
	 * constructor with outstanding setting
	 */
	public Performer(String firstname, String lastname, Gender gender, Movie movie, boolean outstanding) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.gender = gender;
		this.movie = movie;
		this.outstanding = outstanding;
	}
	
	/**
	 * @param firstname Firstname
	 * @param lastname Lastname
	 * @param gender Gender
	 * @param movie Movie
	 * constructor without outstanding setting
	 */
	public Performer(String firstname, String lastname, Gender gender, Movie movie) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.gender = gender;
		this.movie = movie;
		this.outstanding = false;
	}

	/**
	 * @return firstname
	 */
	public String getFirstname() {
		return firstname;
	}

	/**
	 * @param firstname
	 * changes firstname
	 */
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	/**
	 * @return lastname
	 */
	public String getLastname() {
		return lastname;
	}

	/**
	 * @param lastname
	 * changes lastname
	 */
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	/**
	 * @return gender
	 */
	public Gender getGender() {
		return gender;
	}

	/**
	 * @param gender
	 * changes gender
	 */
	public void setGender(Gender gender) {
		this.gender = gender;
	}

	/**
	 * @return movie
	 */
	public Movie getMovie() {
		return movie;
	}

	/**
	 * @param movie
	 * changes weird movie
	 */
	public void setMovie(Movie movie) {
		this.movie = movie;
	}

	/**
	 * @return if performer is outstanding
	 */
	public boolean isOutstanding() {
		return outstanding;
	}

	/**
	 * @param outstanding
	 * set if performer is outstanding
	 */
	public void setOutstanding(boolean outstanding) {
		this.outstanding = outstanding;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	/**
	 * overload toString for better print-Output.
	 * @return formatted string
	 */
	public String toString() {
		return "Name: "+firstname+" "+lastname+LINESEP+
		"Geschlecht: "+gender+LINESEP+
		"Movie: "+movie+LINESEP+
		"Outstanding: "+outstanding+LINESEP;
	}
}
