package de.unihd.isw.moviemanager;

/**
 * @author Johannes Visintini
 * @version 1.0
 */
public enum Gender {
	MALE, FEMALE;
}
