package de.unihd.isw.isw11;

/**
 * @author Philip Bell
 *
 */
public class Performer {
	/**
	 * saves the firstname
	 */
	private String firstname;
	/**
	 * saves the lastname
	 */
	private String lastname;
	/**
	 * saves the current gender of the performer
	 */
	private Gender gender;
	/**
	 * saves a movie or stuff like that
	 */
	private Movie movie;

	/**
	 * @return the firstname of the performer
	 */
	public String getFirstname() {
		return firstname;
	}

	/**
	 * @param firstname changes the firstname of the performer
	 */
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	/**
	 * @return the lastname of the performer
	 */
	public String getLastname() {
		return lastname;
	}

	/**
	 * @param lastname changes the lastname of the performer
	 */
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	/**
	 * @return the gender of the performer
	 */
	public Gender getGender() {
		return gender;
	}

	/**
	 * @param gender changes the gender of the performer
	 */
	public void setGender(Gender gender) {
		this.gender = gender;
	}
	
	/**
	 * @return the movie of the performer
	 */
	public Movie getMovie() {
		return movie;
	}
	
	/**
	 * @param movie changes the movie of the performer
	 */
	public void setMovie(Movie movie) {
		this.movie = movie;
	}

	/**
	 * @param firstname v.s.
	 * @param lastname v.s.
	 * @param gender v.s.
	 * @param movie v.s.
	 */
	public Performer(String firstname, String lastname, Gender gender, Movie movie) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.gender = gender;
		this.movie = movie;
	}
}
