package de.unihd.isw.isw11;

/**
 * @author Philip Bell
 *
 */
public enum Gender {
	/**
	 * Male
	 */
	MALE, /**
	 * or Female
	 */
	FEMALE;
}
