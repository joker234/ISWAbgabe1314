package de.unihd.isw.isw11;

/**
 * @author Johannes Visintini
 *
 */
public class Movie {
	/**
	 * saves title
	 */
	private String title;
	/**
	 * saves duration
	 */
	private int time;
	/**
	 * saves internal number of movie
	 */
	private int number;
	/**
	 * next available internal number for next movie
	 */
	private static int nextNummer=0;

	/**
	 * @param title v.s.
	 * @param time v.s.
	 * sets this to new movie
	 */
	public Movie(String title, int time) {
		super();
		this.title = title;
		this.time = time;
		this.number = nextNummer;
		nextNummer++;
	}
	
	/**
	 * @return title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * Die Funktion bekommt einen Titel in die Variable title übergeben und setzt
	 * diese dann als Titel in dem Objekt der Klasse Movie (this.title)
	 */
	/**
	 * @param title changes title
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * @return duration
	 */
	public int getTime() {
		return time;
	}

	/**
	 * @param time changes duration
	 */
	public void setTime(int time) {
		this.time = time;
	}
	
	/**
	 * @return ID
	 */
	public int getNumber() {
		return number;
	}
	
	/**
	 * print everything
	 */
	public void showInformation() {
		System.out.println("Title: "+this.getTitle());
		System.out.println("Time: "+this.getTime());
		System.out.println("Number: "+this.getNumber());
	}

	/**
	 * @param args
	 * do the required stuff
	 */
	public static void main(String[] args) {
		Movie moviem;
		moviem = new Movie("deine Mutter",50);
		moviem.showInformation();
	}
}