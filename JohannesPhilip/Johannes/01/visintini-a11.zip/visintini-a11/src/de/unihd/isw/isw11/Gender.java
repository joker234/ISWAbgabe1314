package de.unihd.isw.isw11;

/**
 * @author Johannes Visintini
 *
 */
public enum Gender {
	/**
	 * Male
	 */
	MALE, /**
	 * or Female
	 */
	FEMALE;
}
