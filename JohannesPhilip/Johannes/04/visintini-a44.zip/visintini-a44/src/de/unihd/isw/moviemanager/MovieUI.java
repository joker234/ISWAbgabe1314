/* Codebase from Christian Lang */
package de.unihd.isw.moviemanager;



import javax.swing.AbstractAction;
import javax.swing.BoxLayout;
import javax.swing.DefaultCellEditor;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableRowSorter;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * The Class MovieUI.
 */
public class MovieUI extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** The Constant WINDOW_SIZE_X. */
	private static final int WINDOW_SIZE_X = 800;

	/** The Constant WINDOW_SIZE_Y. */
	private static final int WINDOW_SIZE_Y = 400;

	/** The Constant TITLE. */
	private static final String TITLE = "Movie Manager";

	/** The panel. */
	private JPanel panel;

	/** The panel top row. */
	private JPanel panelTopRow;

	/** The text field filter. */
	private JTextField textFieldFilter;

	/** The button. */
	private JButton button;

	/** The table. */
	private JTable table;

	/** The model. */
	private MovieTableModel model;

	/** The manager. */
	private final MovieManager manager;
	
	JPopupMenu kontext1 = new JPopupMenu();
	
	private int row;

	MouseAdapter mouse = new MouseAdapter() {
		@Override
		public void mousePressed(MouseEvent event) {
			if (event.getButton()==3) {
				// Show Kontextmenu
				row = table.rowAtPoint(event.getPoint());
				kontext1.show(event.getComponent(), event.getX(), event.getY());
			}
		}
	};
	
	/**
	 * Instantiates a new movie ui.
	 */
	public MovieUI() {
		manager = new MovieManager();
		showGui();	
	}
	
	/**
	 * Show gui.
	 */
	private void showGui()
	{
		/*
		 * GUI zugriffe sollten im event-dispatching thread verarbeitet werden
		 * um race-conditions zu vermeiden
		 */
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				setDefaultCloseOperation(EXIT_ON_CLOSE);
				setTitle(TITLE);

				initGUI();
				initButtonListeners();

				pack();
				setVisible(true);
				setLocationRelativeTo(null);
			}
		});
	}

	/**
	 * Creates the test movies.
	 */
	public void createTestMovies() {
		Movie movie;
		for (int i = 0; i < 70; i++) {
			movie = new Movie("Film " + i, i * 10, "DE", "no description",
					"everywhere");
			manager.addMovie(movie);
		}
	}
	
	/**
	 * Filters the movies.
	 */
	private void filter() {
		TableRowSorter<MovieTableModel> filterSorter = new TableRowSorter<MovieTableModel>(model);
		table.setRowSorter(filterSorter);
		filterSorter.setRowFilter(RowFilter.regexFilter(textFieldFilter.getText()));
	}

	/**
	 * Inits the gui.
	 */
	private void initGUI() {
		// Erstelle Panel mit Scrollbars
		panel = new JPanel();
		panel.setPreferredSize(new Dimension(WINDOW_SIZE_X, WINDOW_SIZE_Y));
		final JScrollPane scrollPane = new JScrollPane(panel);
		scrollPane
				.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane
				.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		add(scrollPane);
		panel.setLayout(new BoxLayout(panel, BoxLayout.PAGE_AXIS));

		// Top Row
		panelTopRow = new JPanel();
		panelTopRow.setLayout(new BoxLayout(panelTopRow, BoxLayout.LINE_AXIS));
		panelTopRow.setMaximumSize(new Dimension(1920, 32));
		panel.add(panelTopRow);

		final JLabel label = new JLabel("Filter");
		panelTopRow.add(label);

		textFieldFilter = new JTextField();
		panelTopRow.add(textFieldFilter);

		button = new JButton();
		button.setIcon(new ImageIcon("button.png"));
		button.setPreferredSize(new Dimension(32, 32));
		button.setMinimumSize(new Dimension(32, 32));
		panelTopRow.add(button);

		// Table
		model = new MovieTableModel(manager.getMovieList());
		table = new JTable(model);

		final TableRowSorter<MovieTableModel> sorter = new TableRowSorter<MovieTableModel>(
				model);
		table.setRowSorter(sorter);

		final JScrollPane scrollPaneTable = new JScrollPane(table);
		scrollPaneTable
				.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPaneTable
				.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPaneTable.setPreferredSize(new Dimension(WINDOW_SIZE_X,
				WINDOW_SIZE_Y));
		panel.add(scrollPaneTable);

		// Cell-Editor für Language-Spalte.
		TableColumn col = table.getColumnModel().getColumn(3);
		final JComboBox<String> comboBox = new JComboBox<String>();
		comboBox.addItem("ENG");
		comboBox.addItem("DE");
		comboBox.addItem("JP");
		col.setCellEditor(new DefaultCellEditor(comboBox));

		// Spalten 1 und 3 linksbündig machen
		col = table.getColumnModel().getColumn(0);
		DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
		renderer.setHorizontalAlignment(JLabel.LEFT);
		col.setCellRenderer(renderer);

		col = table.getColumnModel().getColumn(2);
		renderer = new DefaultTableCellRenderer();
		renderer.setHorizontalAlignment(JLabel.LEFT);
		col.setCellRenderer(renderer);

		// add "Add Movie" and "Delete Movie" to the kontext menu 
		table.addMouseListener(mouse);
		kontext1.add(new AbstractAction("Add Movie") {
			private static final long serialVersionUID = -5357729362924688042L;
			public void actionPerformed (ActionEvent event) {
				manager.addMovie(new Movie("",0,"","",""));
				table.updateUI();
			}
		});
		kontext1.add(new AbstractAction("Delete Movie") {
			private static final long serialVersionUID = -6540103838600854605L;
			public void actionPerformed (ActionEvent event) {
				manager.delMovie(row);
				table.updateUI();
			}
		});
		
		// added filter Listener
		textFieldFilter.getDocument().addDocumentListener(
				new DocumentListener() {
					public void insertUpdate(DocumentEvent event) {
						filter();
					}
					public void removeUpdate(DocumentEvent event) {
						filter();
					}
					public void changedUpdate(DocumentEvent event) {
						filter();
					}
				}
		);
	}

	/**
	 * Inits the button listeners.
	 */
	private void initButtonListeners() {
		/*
		 * Da keine hinzufügen funktion benötigt, wird stattdessen showInfo
		 * aufgerufen um zu testen, ob sich die Daten nicht nur in der Tabelle,
		 * sondern auch in der ArrayList verändern
		 */
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				manager.addMovie(new Movie("",0,"","",""));
				table.updateUI();
				showInfo();
			}
		});
	}

	/**
	 * Show info.
	 */
	private void showInfo() {
		/*
		 * Testfunktion, funktioniert nur wenn nach id sortiert ist
		 */
		final int row = table.getSelectedRow();
		if (row >= 0) {
			final Movie movie = manager.getMovie(row);
			System.out.println(movie);
		}
	}

}