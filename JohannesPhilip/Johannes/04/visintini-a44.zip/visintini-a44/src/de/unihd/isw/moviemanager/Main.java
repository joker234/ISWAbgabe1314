/* Codebase from Christian Lang */
package de.unihd.isw.moviemanager;

import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

/**
 * The Class Main.
 */
public class Main {

	/**
	 * The main method.
	 * 
	 * @param args
	 *            the arguments
	 */
	public static void main(String[] args) {
		/*
		 * Standard LookAndFeel sieht veraltet aus, daher wird versucht das
		 * interessantere NimbusLookAndFeel zu verwenden
		 */
		try {
			UIManager
					.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
		} catch (ClassNotFoundException e) {
			System.out.println("can not use NimbusLookAndFeel");
		} catch (InstantiationException e) {
			System.out.println("can not use NimbusLookAndFeel");
		} catch (IllegalAccessException e) {
			System.out.println("can not use NimbusLookAndFeel");
		} catch (UnsupportedLookAndFeelException e) {
			System.out.println("can not use NimbusLookAndFeel");
		}

		final MovieUI gui = new MovieUI();
		gui.createTestMovies();
	}

}
