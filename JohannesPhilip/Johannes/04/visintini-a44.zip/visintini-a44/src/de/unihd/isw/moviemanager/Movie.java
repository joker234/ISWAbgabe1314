/* Codebase from Christian Lang */
package de.unihd.isw.moviemanager;

/**
 * The Class Movie.
 */
public class Movie{

	/** The name. */
	private String name;
	
	/** The time. */
	private int time;
	
	/** The language. */
	private String language;
	
	/** The description. */
	private String description;
	
	/** The place. */
	private String place;
	
	/** The id. */
	private int id;
	
	/** The next number. */
	private static int nextNumber = 1;

	
	/**
	 * Instantiates a new movie.
	 *
	 * @param name the name
	 * @param time the time
	 * @param language the language
	 * @param description the description
	 * @param place the place
	 */
	public Movie(String name, int time, String language,
			String description, String place)
	{
		id = nextNumber;
		nextNumber++;
		this.name = name;
		this.time = time;
		this.language = language;
		this.description = description;
		this.place = place;
	}	

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Movie [name=" + name + ", time=" + time + ", language="
				+ language + ", description=" + description + ", place="
				+ place + ", id=" + id + "]";
	}



	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Gets the time.
	 *
	 * @return the time
	 */
	public int getTime() {
		return time;
	}

	/**
	 * Sets the time.
	 *
	 * @param time the new time
	 */
	public void setTime(int time) {
		this.time = time;
	}

	/**
	 * Gets the language.
	 *
	 * @return the language
	 */
	public String getLanguage() {
		return language;
	}

	/**
	 * Sets the language.
	 *
	 * @param language the new language
	 */
	public void setLanguage(String language) {
		this.language = language;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Sets the description.
	 *
	 * @param description the new description
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * Gets the place.
	 *
	 * @return the place
	 */
	public String getPlace() {
		return place;
	}

	/**
	 * Sets the place.
	 *
	 * @param place the new place
	 */
	public void setPlace(String place) {
		this.place = place;
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public int getId() {
		return id;
	}
		
	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(int id)
	{
		this.id = id;
	}
	
}
