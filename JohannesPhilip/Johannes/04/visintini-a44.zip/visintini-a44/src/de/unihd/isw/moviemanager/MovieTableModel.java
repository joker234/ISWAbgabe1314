/* Codebase from Christian Lang */
package de.unihd.isw.moviemanager;

import java.util.List;

import javax.swing.table.AbstractTableModel;

/**
 * The Class MovieTableModel.
 */
public class MovieTableModel extends AbstractTableModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** The column names. */
	private final String[] columnNames = { "Id", "Name", "Time", "Language",
			"Description", "Place" };

	/** The data. */
	private final List<Movie> data;
	
	/**
	 * Instantiates a new movie table model.
	 *
	 * @param movieList the movie list
	 */
	public MovieTableModel(List<Movie> movieList)
	{
		data = movieList;
	}	

	/**
	 * (non-Javadoc).
	 *
	 * @return the column count
	 * @see javax.swing.table.TableModel#getColumnCount()
	 */
	public int getColumnCount() {
		return columnNames.length;
	}

	/**
	 * (non-Javadoc).
	 *
	 * @return the row count
	 * @see javax.swing.table.TableModel#getRowCount()
	 */
	public int getRowCount() {
		return data.size();
	}

	/**
	 * (non-Javadoc).
	 *
	 * @param col the col
	 * @return the column name
	 * @see javax.swing.table.AbstractTableModel#getColumnName(int)
	 */
	public String getColumnName(int col) {
		return columnNames[col];
	}

	/**
	 * (non-Javadoc).
	 *
	 * @param row the row
	 * @param column the column
	 * @return the value at
	 * @see javax.swing.table.TableModel#getValueAt(int, int)
	 */
	public Object getValueAt(int row, int column) {
		final Movie e = data.get(row);
		switch (column) {
		case 0:
			return e.getId();
		case 1:
			return e.getName();
		case 2:
			return e.getTime();
		case 3:
			return e.getLanguage();
		case 4:
			return e.getDescription();
		case 5:
			return e.getPlace();
		default:
			return null;
		}
	}

	// Damit JTable den Datentyp erkennt
	/**
	 * (non-Javadoc).
	 *
	 * @param columnIndex the column index
	 * @return the column class
	 * @see javax.swing.table.AbstractTableModel#getColumnClass(int)
	 */
	public Class<?> getColumnClass(int columnIndex) {
		return getValueAt(0, columnIndex).getClass();
	}
	
	/**
	 * (non-Javadoc).
	 *
	 * @param row the row
	 * @param col the col
	 * @return true, if is cell editable
	 * @see javax.swing.table.AbstractTableModel#isCellEditable(int, int)
	 */
	public boolean isCellEditable(int row, int col) {
		if (col < 1) {
			return false;
		} 
		return true;
	}

	
	/**
	 * (non-Javadoc).
	 *
	 * @param value the value
	 * @param row the row
	 * @param column the column
	 * @see javax.swing.table.AbstractTableModel#setValueAt(java.lang.Object, int, int)
	 */
	public void setValueAt(Object value, int row, int column) {

		final Movie e = data.get(row);
		switch (column) {
		case 0:
			e.setId((int) value);
			fireTableCellUpdated(row, column);
			break;
		case 1:
			e.setName((String) value);
			fireTableCellUpdated(row, column);
			break;
		case 2:
			e.setTime((int) value);
			fireTableCellUpdated(row, column);
			break;
		case 3:
			e.setLanguage((String) value);
			fireTableCellUpdated(row, column);
			break;
		case 4:
			e.setDescription((String) value);
			fireTableCellUpdated(row, column);
			break;
		case 5:
			e.setPlace((String) value);
			fireTableCellUpdated(row, column);
			break;
		default:
			break;
		}
	}
	
	
}
