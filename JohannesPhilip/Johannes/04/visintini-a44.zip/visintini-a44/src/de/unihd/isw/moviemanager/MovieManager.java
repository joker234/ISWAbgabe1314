/* Codebase from Christian Lang */
package de.unihd.isw.moviemanager;

/* import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream; */
import java.util.ArrayList;
import java.util.List;

/**
 * The Class MovieManager.
 */
public class MovieManager {

	/** The movie list. */
	private List<Movie> movieList;
	
	/**
	 * Instantiates a new movie manager.
	 */
	public MovieManager()
	{
		movieList = new ArrayList<Movie>();
		/* loadMovies("/tmp/movie.out"); */
	}
	
	/**
	 * Gets the movie.
	 *
	 * @param index the index
	 * @return the movie
	 */
	public Movie getMovie(int index)
	{
		return movieList.get(index);
	}
	
	/**
	 * Gets the size.
	 *
	 * @return the size
	 */
	public int getSize()
	{
		return movieList.size();
	}
	
	/**
	 * Adds the movie.
	 *
	 * @param movie the movie
	 */
	public void addMovie(Movie movie)
	{
		movieList.add(movie);
		/* saveMovies("/tmp/movie.out"); */
	}
	
	/**
	 * Deletes the movie.
	 * 
	 * @param index the index
	 */
	public void delMovie(int index) {
		movieList.remove(index);
		/* saveMovies("/tmp/movie.out"); */
	}
	
	/**
	 * Gets the movie list.
	 *
	 * @return the movie list
	 */
	public List<Movie> getMovieList()
	{
		return movieList;
	}

	/* private void loadMovies(String path) {
		try {
	        FileInputStream file = new FileInputStream(path);
	        ObjectInputStream input = new ObjectInputStream(file);
	        List<Movie> readObject = (List<Movie>) input.readObject();
			movieList = readObject;
	        input.close();
	        file.close();
	    } catch(IOException exept) {
	        System.out.println(exept);
	    } catch(ClassNotFoundException exept) {
	        System.out.println(exept);
	    }
	} */
	
	/* public void saveMovies(String path) {
        try {
            FileOutputStream file = new FileOutputStream(path);
            ObjectOutputStream output = new ObjectOutputStream(file);
            output.writeObject(movieList);
            output.close();
            file.close();
        } catch (IOException exept) {
            System.out.println("Error: Coudldn't write to file");
            exept.printStackTrace();
        }
    } */

}
