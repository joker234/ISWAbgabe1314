package movieManagement;
/*
* MovieManager
*
* Version 1.0 Moritz Nöltner
*
* You don't want to copy this.
* But if, for whatever reason, you still want to, feel free.
*/

/**
* Gender
*
* You don't want to copy this.
* But if, for whatever reason, you still want to, feel free.
* 
* @version 22.10.2013
* @author mox
* @project noeltner-a23
*/
public enum Gender {
	/**
	 * The Male gender.
	 */
	Male,
	/**
	 * The Female gender.
	 */
	Female;
}
