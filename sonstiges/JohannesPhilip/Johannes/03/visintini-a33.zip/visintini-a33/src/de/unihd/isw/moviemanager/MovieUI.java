package de.unihd.isw.moviemanager;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import java.awt.BorderLayout;

/**
 * @author Johannes Visintini
 *
 */
public class MovieUI {

	
	/**
	 * @param args normal stdin args
	 */
	public static void main(String[] args) {
		final Movie m1 = new Movie("Star Wars", 250, Language.EN, "ööööh keine Ahnung", Country.CH);
		final Movie m2 = new Movie("Star Wars 2", 25, Language.GER, "Dieser Film ist toll!", Country.GER);
		final Movie m3 = new Movie("Star Wars 3", 125, Language.JP, "Dieser Film ist auch toll!", Country.UK);
		final Movie m4 = new Movie("Star Wars 4", 215, Language.EN, "Dieser Film ist toll …", Country.USA);
		final Movie m5 = new Movie("Star Wars 5", 235, Language.GER, "oder so", Country.CH);
		final Movie[] movies = {m1,m2,m3,m4,m5};
		
		final JTable table = new MovieTableModel(movies).getTable();
		
		final JFrame mainFrame = new JFrame("Movie Manager");
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setSize(200,200);
        
        final JPanel topLeftPanel = new JPanel(new BorderLayout());
        final JLabel label = new JLabel("Filter");
        topLeftPanel.add(label);

        final JPanel topMiddlePanel = new JPanel(new BorderLayout());
        final JTextField filterInput = new JTextField();
        topMiddlePanel.add(filterInput);
        
        final JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.add(topLeftPanel, BorderLayout.WEST);
        topPanel.add(topMiddlePanel, BorderLayout.CENTER);
       
        final JScrollPane scrollPane = new JScrollPane(table);
        
        mainFrame.add(topPanel, BorderLayout.PAGE_START);
        mainFrame.add(scrollPane, BorderLayout.CENTER);
        
		mainFrame.setVisible(true);
		}
}
