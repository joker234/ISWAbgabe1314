package de.unihd.isw.moviemanager;

/**
 * @author Johannes Visintini
 * Enthält verfügbare Sprachen
 */
public enum Language {
	GER("German", "ger"),
	EN ("English", "en"),
	JP ("Japanese", "jp");
	
	private final String name;
	private final String abbreviation;
	
	private Language(String name, String abbreviation) {
		this.name = name;
		this.abbreviation = abbreviation;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @return the abbreviation
	 */
	public String getAbbreviation() {
		return abbreviation;
	}
}
