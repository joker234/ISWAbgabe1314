// $codepro.audit.disable
package de.unihd.isw.moviemanager;

import java.io.Serializable;

/**
 * @author Johannes Visintini
 *
 */
public class Movie implements Serializable {
	
	/**
	 * contains UID.
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * contains string.
	 */
	private final String name;
	/**
	 * contains duration.
	 */
	private final int duration;
	/**
	 * contains language.
	 */
	private Language language;
	/**
	 * contains description.
	 */
	private String description;
	/**
	 * contais Location.
	 */
	private Country location;
	/**
	 * contains loaner.
	 */
	private Customer loaner;
	/**
	 * contains number.
	 */
	private final int nummer;
	/**
	 * contains next number for all.
	 */
	private static int nextNummer;
	
	/**
	 * @param name sets name
	 * @param dur sets duration
	 * @param lang sets language
	 * @param desc sets description
	 * @param loc sets location
	 */
	public Movie(String name, int dur, Language lang, String desc, Country loc) {
		this.name = name;
		this.duration = dur;
		this.language = lang;
		this.description = desc;
		this.location = loc;
		this.nummer = nextNummer;
		nextNummer++;
	}

	/**
	 * @return number
	 */
	public int getNummer() {
		return nummer;
	}
	
	/**
	 * @return name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @return duration
	 */
	public int getDuration() {
		return duration;
	}

	/**
	 * @return language
	 */
	public Language getLanguage() {
		return language;
	}

	/**
	 * @param language sets language
	 */
	public void setLanguage(Language language) {
		this.language = language;
	}

	/**
	 * @return description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description sets description
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return location
	 */
	public Country getLocation() {
		return location;
	}

	/**
	 * @param location sets location
	 */
	public void setLocation(Country location) {
		this.location = location;
	}

	/**
	 * @return the loaner
	 */
	public Customer getLoaner() {
		return loaner;
	}

	/**
	 * @param loaner the loaner to set
	 */
	public void setLoaner(Customer loaner) {
		this.loaner = loaner;
	}
}
