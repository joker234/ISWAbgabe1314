package de.unihd.isw.moviemanager;

import javax.swing.JTable;
import javax.swing.JComboBox;
import javax.swing.DefaultCellEditor;
import javax.swing.table.TableColumn;
import java.util.ArrayList;

/**
 * @author Johannes Visintini
 *
 */
public class MovieTableModel {
	private final JTable table;
	private final ArrayList<Object[]> data;
	private final String[] columnNames = {"Id", "Name", "Time", "Language", "Description", "Place"};
	private final JComboBox<Language> langList = new JComboBox<Language>();
	private final JComboBox<Country> locList = new JComboBox<Country>();
    
    /**
     * @param movies which movie to create
     */
    public MovieTableModel(Movie[] movies) {
    	data = new ArrayList<Object[]>();
    	for(Movie movie : movies) {
    		Object[] tmp = {
    				movie.getNummer(),
    				movie.getName(),
    				movie.getDuration(),
    				movie.getLanguage(),
    				movie.getDescription(),
    				movie.getLocation()
    				};
    		data.add(tmp);
    	}
		this.table = new JTable(data.toArray(new Object[data.size()][data.size()]), columnNames);
		final TableColumn langColumn = table.getColumnModel().getColumn(3);
		final TableColumn locColumn = table.getColumnModel().getColumn(5);
		for(Language lang : Language.values()) {
			langList.addItem(lang);
		}
		for(Country country : Country.values()) {
			locList.addItem(country);
		}
		table.setFillsViewportHeight(false);
		table.setAutoCreateRowSorter(true);
		langColumn.setCellEditor(new DefaultCellEditor(langList));
		locColumn.setCellEditor(new DefaultCellEditor(locList));
	}
    
    /**
     * @return the table
     */
    public JTable getTable() {
    	return table;
    }
  
}