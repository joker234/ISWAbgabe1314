package de.unihd.isw.moviemanager;

/**
 * @author Johannes Visintini
 *
 */
public enum Country {
	GER("Germany", "ger"),
	CH ("Switzerland", "ch"),
	USA("America", "usa"),
	UK ("United Kingdom", "uk");
	
	private final String name;
	private final String abbreviation;
	
	private Country(String name, String abbreviation) {
		this.name = name;
		this.abbreviation = abbreviation;
	}

	/**
	 * @return name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @return abbreviation
	 */
	public String getAbbreviation() {
		return abbreviation;
	}
}
