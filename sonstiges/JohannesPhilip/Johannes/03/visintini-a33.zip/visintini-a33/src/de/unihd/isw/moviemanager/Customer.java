package de.unihd.isw.moviemanager;

import java.util.Set;
import java.util.HashSet;

/**
 * 
 * @author Johannes Visintini, Philip Bell
 *
 */
public class Customer {
	/**
	 * Name des Kunden.
	 */
	private String name;
	/**
	 * ausgeliehene Filme.
	 */
	private Set<Movie> loanedMovies;
	/**
	 * @param name setze namen
	 */
	public Customer(String name){
		this.name = name;
		this.loanedMovies = new HashSet<Movie>();
	}
	/**
	 * @param name enthält Namen
	 * @param loaned enthält den ausgeliehenen Film
	 */
	public Customer(String name, Set<Movie> loaned){
		this.name = name;
		this.loanedMovies = loaned;
	}
	
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * @param movie movie to lend
	 */
	public void loanMovie(Movie movie){
		if(movie.getLoaner() != null) {
			System.out.println("Film ist schon an Kunde "+movie.getLoaner().getName()+" verliehen");
		} else if(loanedMovies.size()>=5) {
			System.out.println("Kunde "+name+" hat schon 5 Filme ausgeliehen");
		} else {
			loanedMovies.add(movie);
			movie.setLoaner(this);
			System.out.println("Kunde "+name+" hat den Film "+movie.getName()+" ausgeliehen");
		}
	}
	

}
