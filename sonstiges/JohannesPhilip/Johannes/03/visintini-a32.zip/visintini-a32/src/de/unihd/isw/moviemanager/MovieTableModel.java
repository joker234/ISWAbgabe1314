package de.unihd.isw.moviemanager;

import javax.swing.*;
import javax.swing.table.*;
import java.util.ArrayList;

/**
 * @author Johannes Visintini
 *
 */
public class MovieTableModel {
	JTable table;
	ArrayList<Object[]> data;
	String[] columnNames = {"Id", "Name", "Time", "Language", "Description", "Place"};
	JComboBox<Language> LangList = new JComboBox<Language>();
	JComboBox<Country> LocList = new JComboBox<Country>();
    
    public MovieTableModel(Movie[] movies) {
    	data = new ArrayList<Object[]>();
    	for(Movie movie : movies) {
    		Object[] tmp = {
    				movie.getNummer(),
    				movie.getName(),
    				movie.getDuration(),
    				movie.getLanguage(),
    				movie.getDescription(),
    				movie.getLocation()
    				};
    		data.add(tmp);
    	}
		this.table = new JTable(data.toArray(new Object[data.size()][data.size()]), columnNames);
		TableColumn LangColumn = table.getColumnModel().getColumn(3);
		TableColumn LocColumn = table.getColumnModel().getColumn(5);
		for(Language lang : Language.values()) {
			LangList.addItem(lang);
		}
		for(Country country : Country.values()) {
			LocList.addItem(country);
		}
		table.setFillsViewportHeight(false);
		table.setAutoCreateRowSorter(true);
		LangColumn.setCellEditor(new DefaultCellEditor(LangList));
		LocColumn.setCellEditor(new DefaultCellEditor(LocList));
	}
    
    public JTable getTable() {
    	return table;
    }
  
}