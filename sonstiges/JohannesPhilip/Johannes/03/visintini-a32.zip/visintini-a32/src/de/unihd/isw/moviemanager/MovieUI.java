package de.unihd.isw.moviemanager;

import javax.swing.*;
import java.awt.*;

/**
 * @author Johannes Visintini
 *
 */
public class MovieUI {

	
	public static void main(String[] args) {
		Movie m1 = new Movie("Star Wars", 250, Language.EN, "ööööh keine Ahnung", Country.CH);
		Movie m2 = new Movie("Star Wars 2", 25, Language.GER, "Dieser Film ist toll!", Country.GER);
		Movie m3 = new Movie("Star Wars 3", 125, Language.JP, "Dieser Film ist auch toll!", Country.UK);
		Movie m4 = new Movie("Star Wars 4", 215, Language.EN, "Dieser Film ist toll …", Country.USA);
		Movie m5 = new Movie("Star Wars 5", 235, Language.GER, "oder so", Country.CH);
		Movie[] movies = {m1,m2,m3,m4,m5};
		
		JTable table = new MovieTableModel(movies).getTable();
		
		JFrame mainFrame = new JFrame("Movie Manager");
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setSize(200,200);
        
        JPanel topLeftPanel = new JPanel(new BorderLayout());
        JLabel label = new JLabel("Filter");
        topLeftPanel.add(label);

        JPanel topMiddlePanel = new JPanel(new BorderLayout());
        final JTextField filterInput = new JTextField();
        topMiddlePanel.add(filterInput);
        
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.add(topLeftPanel, BorderLayout.WEST);
        topPanel.add(topMiddlePanel, BorderLayout.CENTER);
       
        JScrollPane scrollPane = new JScrollPane(table);
        
        mainFrame.add(topPanel, BorderLayout.PAGE_START);
        mainFrame.add(scrollPane, BorderLayout.CENTER);
        
		mainFrame.setVisible(true);
		}
}
