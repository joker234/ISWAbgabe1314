package de.unihd.isw.moviemanager;

import java.util.HashSet;
import java.util.Iterator;

/**
 * @author Johannes Visintini
 *
 */
public class Movie {
	/**
	 * saves title
	 */
	private String title;
	/**
	 * saves duration
	 */
	private int time;
	/**
	 * saves internal number of movie
	 */
	private int number;
	/**
	 * next available internal number for next movie
	 */
	private static int nextNummer=0;
	
	
	/**
	 * saves Performers in HashSet
	 * I used a HashSet because HashMap is not necessary, the values ar not
	 * necessary. ArrayList is not necessary either because the values (performers)
	 * have no order.
	 */
	private HashSet<Performer> set = new HashSet<Performer>();

	/**
	 * @param title
	 * @param time
	 * constructor for movie class
	 */
	public Movie(String title, int time) {
		super();
		this.title = title;
		this.time = time;
		this.number = nextNummer;
		nextNummer++;
	}
	
	/**
	 * @return title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * Die Funktion bekommt einen Titel in die Variable title übergeben und setzt
	 * diese dann als Titel in dem Objekt der Klasse Movie (this.title)
	 */
	/**
	 * @param title
	 * changes title
	 */
	public void setTitle(String title) {
		this.title = title;
	} // 

	/**
	 * @return duration
	 */
	public int getTime() {
		return time;
	}

	/**
	 * @param time
	 * changes duration
	 */
	public void setTime(int time) {
		this.time = time;
	}
	
	/**
	 * @return number
	 */
	public int getNumber() {
		return number;
	}
	
	/**
	 * print out all available Basic information
	 */
	public void showInformation() {
		System.out.println("Nummer:"+this.getNumber());
		System.out.println("Titel:"+this.getTitle());
		System.out.println("Länge:"+this.getTime());
	}
	
	/**
	 * @param p
	 * adds the performer to the set
	 */
	public void addPerformer(Performer p) {
		this.set.add(p);
	}
	
	/**
	 * @return all performers as HashSet
	 */
	public HashSet<Performer> getPerformer() {
		return set;
	}

	/**
	 * @param ss
	 * @return if String ss is contained in the name of Performers
	 */
	public boolean isPerformer(String ss) { //ss = searchString
		Performer[] array = this.getPerformer().toArray(new Performer[getPerformer().size()]);
		boolean out = false;
		for(int i=0;i<array.length;i++) {
			out = (array[i].getFirstname().contains(ss)||array[i].getLastname().contains(ss));
			if (out) { break; }
		}
		return out;
	}
	
	/**
	 * @return all outstanding performers
	 */
	public HashSet<Performer> getOutstandingPerformer() {
		HashSet<Performer> out = new HashSet<Performer>();
		Iterator<Performer> it = set.iterator();
		while (it.hasNext()) {
			Performer cur = it.next();
			if (cur.isOutstanding()) {
				out.add(cur);
			}
		}
		return out;
	}
	
	/**
	 * @param p
	 * remove Performers from HashSet
	 */
	public void removePerformer(Performer p) {
		set.remove(p);
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 * overload toString for better print-Output
	 */
	public String toString() {
		return title+" ("+time+")";
	}
	
	public static void main(String[] args) {
		Movie Film;
		Film = new Movie("Häwassollndas",50);
		Film.showInformation();
	}

}
