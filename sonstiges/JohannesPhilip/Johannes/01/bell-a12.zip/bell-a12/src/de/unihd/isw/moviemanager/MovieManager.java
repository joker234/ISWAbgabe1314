package de.unihd.isw.moviemanager;

public class MovieManager {
	// Kommentare siehe Output
	public static void main(String[] args) {
		System.out.println("Lege Film 'Zombie' mit 50 Laufzeit an");
		Movie bla = new Movie("Zombie",50);
		Performer p = new Performer("Hans","Wurst",Gender.MALE,bla);
		bla.addPerformer(p);
		System.out.println("Performer1 angelegt und Film zugeordnet");
		Performer p1 = new Performer("Klaus","Kunz",Gender.MALE,bla,true);
		bla.addPerformer(p1);
		System.out.println("Performer2 angelegt und Film zugeordnet");
		Performer p2 = new Performer("Paul","Hübner",Gender.MALE,bla);
		bla.addPerformer(p2);
		System.out.println("Performer3 angelegt und Film zugeordnet");
		Performer p3 = new Performer("Face","Book",Gender.MALE,bla,true);
		bla.addPerformer(p3);
		System.out.println("Performer4 angelegt und Film zugeordnet");
		System.out.println("Test ob Performer mit Namen 'Wurst' am Film mitgewirkt hat:");
		System.out.println(bla.isPerformer("Wurst"));
		System.out.println("Alle Performer ausgegeben:");
		System.out.println(bla.getPerformer());
		System.out.println("Alle Outstanding-Performer ausgegeben:");
		System.out.println(bla.getOutstandingPerformer());
		System.out.println("Eigenschaften von Performer3 ausgeben:");
		System.out.println(p2);
		System.out.println("Performer3 entfernt und alle Performer ausgegeben:");
		bla.removePerformer(p2);
		System.out.println(bla.getPerformer());
	}
}
