package de.unihd.isw.moviemanager;

/**
 * @author Johannes Visintini
 *
 */
public enum Gender {
	/**
	 * Male
	 */
	MALE, /**
	 * or Female
	 */
	FEMALE;
}
