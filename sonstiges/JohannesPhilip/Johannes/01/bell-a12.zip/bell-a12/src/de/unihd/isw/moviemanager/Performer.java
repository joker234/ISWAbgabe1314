package de.unihd.isw.moviemanager;

/**
 * @author Philip Bell
 *
 */
public class Performer {
	/**
	 * saves the firstname
	 */
	private String firstname;
	/**
	 * saves the lastname
	 */
	private String lastname;
	/**
	 * saves the current gender of the performer
	 */
	private Gender gender;
	/**
	 * saves a movie or stuff like that
	 */
	private Movie movie;
	/**
	 * is the performer outstanding?
	 */
	private boolean outstanding;

	/**
	 * @return firstname
	 */
	public String getFirstname() {
		return firstname;
	}

	/**
	 * @param firstname
	 * changes firstname
	 */
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	/**
	 * @return lastname
	 */
	public String getLastname() {
		return lastname;
	}

	/**
	 * @param lastname
	 * changes lastname
	 */
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	/**
	 * @return gender
	 */
	public Gender getGender() {
		return gender;
	}

	/**
	 * @param gender
	 * changes gender
	 */
	public void setGender(Gender gender) {
		this.gender = gender;
	}

	/**
	 * @return movie
	 */
	public Movie getMovie() {
		return movie;
	}

	/**
	 * @param movie
	 * changes weird movie
	 */
	public void setMovie(Movie movie) {
		this.movie = movie;
	}

	/**
	 * @return if performer is outstanding
	 */
	public boolean isOutstanding() {
		return outstanding;
	}

	/**
	 * @param outstanding
	 * set if performer is outstanding
	 */
	public void setOutstanding(boolean outstanding) {
		this.outstanding = outstanding;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 * overload toString for better print-Output
	 */
	public String toString() {
		return ("Name: "+firstname+" "+lastname+"\n"+
		"Geschlecht: "+gender+"\n"+
		"Movie: "+movie+"\n"+
		"Outstanding: "+outstanding+"\n");
	}

	/**
	 * @param firstname
	 * @param lastname
	 * @param gender
	 * @param movie
	 * @param outstanding
	 * constructor with outstanding setting
	 */
	public Performer(String firstname, String lastname, Gender gender, Movie movie, boolean outstanding) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.gender = gender;
		this.movie = movie;
		this.outstanding = outstanding;
	}
	
	/**
	 * @param firstname
	 * @param lastname
	 * @param gender
	 * @param movie
	 * constructor without outstanding setting
	 */
	public Performer(String firstname, String lastname, Gender gender, Movie movie) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.gender = gender;
		this.movie = movie;
		this.outstanding = false;
	}
}
