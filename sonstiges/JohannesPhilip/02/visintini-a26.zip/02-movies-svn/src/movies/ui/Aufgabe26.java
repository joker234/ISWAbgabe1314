package movies.ui;

import movies.system.Country;
import movies.system.Language;
import movies.system.Movie;
import movies.system.Customer;

public class Aufgabe26 {
	public static void main(String[] args) {
		Movie m1 = new Movie("Film1",120,Language.GER,"Description...",Country.CH);
		Movie m2 = new Movie("Film2",120,Language.GER,"Description...",Country.CH);
		Movie m3 = new Movie("Film3",120,Language.GER,"Description...",Country.CH);
		Movie m4 = new Movie("Film4",120,Language.GER,"Description...",Country.CH);
		Movie m5 = new Movie("Film5",120,Language.GER,"Description...",Country.CH);
		Movie m6 = new Movie("Film6",120,Language.GER,"Description...",Country.CH);
		System.out.println("-6 Filme generiert-");
		Customer c1 = new Customer("Peter Paul");
		Customer c2 = new Customer("Frieda Friedz");
		System.out.println("-2 Customer generiert-");
		c1.loanMovie(m1);
		c1.loanMovie(m2);
		c1.loanMovie(m3);
		c1.loanMovie(m4);
		c2.loanMovie(m2);
		c1.loanMovie(m5);
		c1.loanMovie(m6);
	}
}